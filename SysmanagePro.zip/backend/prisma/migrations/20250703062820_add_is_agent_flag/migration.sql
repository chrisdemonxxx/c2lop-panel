-- AlterTable
ALTER TABLE "Client" ADD COLUMN     "is_agent" BOOLEAN NOT NULL DEFAULT false;
