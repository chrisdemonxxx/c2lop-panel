/// <reference types="node" />
declare module 'bcryptjs';
