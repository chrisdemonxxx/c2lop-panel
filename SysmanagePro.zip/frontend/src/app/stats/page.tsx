"use client";
import { useEffect, useState } from "react";
import { useClientStore } from "@/lib/realtimeStore";
import api from "@/lib/api";

// Stats page removed
export default function StatsPage() {
  return null;
}
